console.log("main.js loaded ✔");

const PASSWORD = "1234"; // שנה לסיסמה שלך

/* ============================================
   LOGIN SYSTEM – ONLY FIRST TIME
============================================ */

window.addEventListener("load", () => {
    // בודק אם המשתמש כבר התחבר בעבר
    const loggedIn = localStorage.getItem("devtools_logged_in");

    if (loggedIn === "true") {
        // מסתיר את מסך ההתחברות בכל הדפים
        const loginScreen = document.getElementById("login-screen");
        if (loginScreen) loginScreen.style.display = "none";
    }
});

function checkPass() {
    const inputEl = document.getElementById("loginPass");
    const errorEl = document.getElementById("loginError");

    if (!inputEl) {
        console.error("loginPass input not found!");
        return;
    }

    const entered = inputEl.value.trim();

    if (!entered) {
        errorEl.textContent = "יש להזין סיסמה.";
        errorEl.style.color = "#ff6b6b";
        errorEl.classList.add("show");
        return;
    }

    if (entered === PASSWORD) {
        errorEl.textContent = "סיסמה נכונה – מעביר...";
        errorEl.style.color = "#7dffb3";
        errorEl.classList.add("show");

        // שמירה שהמשתמש נכנס
        localStorage.setItem("devtools_logged_in", "true");

        // אפקט יציאה
        setTimeout(() => {
            const login = document.getElementById("login-screen");
            login.classList.add("fade-out");
            setTimeout(() => {
                login.style.display = "none";
            }, 400);
        }, 500);

    } else {
        errorEl.textContent = "סיסמה שגויה.";
        errorEl.style.color = "#ff6b6b";
        errorEl.classList.add("show");
    }
}



// ====== YAML Validator ======
function validateYAML() {
    const input = document.getElementById("yamlInput").value;
    const out = document.getElementById("yamlOutput");

    try {
        jsyaml.load(input);
        out.textContent = "✓ תקין — אין שגיאות.";
        out.style.color = "#7dffb3";
    } catch (e) {
        out.textContent = "שגיאה:\n" + e.message;
        out.style.color = "#ff8080";
    }
}

// ====== Scroll Reveal ======
const revealElements = document.querySelectorAll(".reveal");

function revealOnScroll() {
    const trigger = window.innerHeight * 0.85;

    revealElements.forEach(el => {
        const rect = el.getBoundingClientRect();
        if (rect.top < trigger) {
            el.classList.add("visible");
        }
    });
}

window.addEventListener("scroll", revealOnScroll);
window.addEventListener("load", revealOnScroll);

function copyColor(hex) {
    navigator.clipboard.writeText(hex);
    alert("הצבע הועתק: " + hex);
}
function copyColor(hex, buttonElement) {
    navigator.clipboard.writeText(hex);

    // אם יש כבר פופ־אפ – מחיקה
    const oldPopup = document.querySelector(".copy-popup");
    if (oldPopup) oldPopup.remove();

    // יצירת הפופ־אפ
    const popup = document.createElement("div");
    popup.className = "copy-popup";
    popup.textContent = "הועתק!";

    // הוספה ליד הכפתור
    document.body.appendChild(popup);

    // מיקום מדויק מעל הכפתור
    const rect = buttonElement.getBoundingClientRect();
    popup.style.left = rect.left + (rect.width / 2) - 35 + "px";
    popup.style.top = rect.top - 5 + window.scrollY + "px";

    // הופעה
    setTimeout(() => popup.classList.add("show"), 10);

    // היעלמות
    setTimeout(() => {
        popup.classList.remove("show");
        setTimeout(() => popup.remove(), 300);
    }, 1800);
}
